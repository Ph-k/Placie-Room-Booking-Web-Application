export class Availability {
  availabilityId: number;
  placeId: number;
  startingDate: number;
  endingDate: number;
}
