export class PendingHost{
  userId: number;
}
