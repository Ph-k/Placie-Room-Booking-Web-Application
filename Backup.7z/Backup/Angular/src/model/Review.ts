export class Review {
  reviewId: number;
  reviewStars: number;
  reviewText: string;
}
