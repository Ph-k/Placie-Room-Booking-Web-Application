export class PlacePhoto {
  placePhotoId: number;
  placeId: number;
  photoUrl: string;
}
