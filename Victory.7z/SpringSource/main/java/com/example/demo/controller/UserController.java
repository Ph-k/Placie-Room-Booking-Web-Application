package com.example.demo.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import com.example.demo.exception.UserNotFoundException;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
class UserController {

    private final UserRepository repository;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;
    public static String PhotosDirectory = System.getProperty("User.dir") + "/ProfilePhotos";
    
    UserController(UserRepository repository,BCryptPasswordEncoder bCryptPasswordEncoder) {
        this.repository = repository;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/Users")
    List<User> all() {
        return repository.findAll();
    }

    @CrossOrigin(origins = "*")
    @PostMapping("/Registration")
    User newUser(@RequestBody User newUser)
    {   newUser.setPassword(bCryptPasswordEncoder.encode(newUser.getPassword()));
        if(repository.findByUsername(newUser.getUserName()) != null ) {
            return null;
        }
        else {
            if(newUser.getIsHost() == true){
                newUser.setIsHost(false);
            }
            return repository.save(newUser);}
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/Users/{id}")
    User one(@PathVariable Long id ){
        return repository.findById(id).orElseThrow(() -> new UserNotFoundException(id));
    }

    @CrossOrigin(origins = "*")
    @PutMapping("/Users/{id}")
    User replaceUser(@RequestBody User newUser,@PathVariable Long id){
        return repository.findById(id).map(User -> {
            User.setEMail(newUser.getEMail());
            User.setFirstName(newUser.getFirstName());
            User.setLastName(newUser.getLastName());
            User.setUserName(newUser.getUserName());
            User.setPassword(newUser.getPassword());
            User.setTelephone(newUser.getTelephone());
            User.setPhotoBytes(newUser.getPhotoBytes());
            User.setIsTenant(newUser.getIsTenant());
            User.setIsHost(newUser.getIsHost());
            User.setIsAdmin(newUser.getIsAdmin());
            return repository.save(newUser);
        }).orElseThrow(() -> new UserNotFoundException(id));
    }

    @GetMapping("/UserId/{Username}")
    Long GetId(@PathVariable String Username ){
        User TUser= repository.findByUsername(Username);//.orElseThrow(() -> new UserNotFoundException(Username));
        if( TUser == null ) return Long.valueOf(-1);
        return TUser.getUserId();

    }

    @RequestMapping(
            value = ("/Users/Image/{username}"),
            headers = "content-type=multipart/form-data",
            method = RequestMethod.POST)
    //@PostMapping("/Users/Image/{username}")
    public int PostImage(@RequestParam("file") MultipartFile Image, @PathVariable String username) throws IOException {
        User TUser = repository.findByUsername(username);
        if( TUser == null ) return -1;
        if( Image.isEmpty() ) return -2;

        String PhotosDirectory = "S:\\filip\\Documents\\DIT\\6ο Εξάμηνο\\ΤΕΔΙ\\AirBnB\\src\\main\\java\\com\\example\\demo\\images\\";
        Image.transferTo(new File(PhotosDirectory + username + ".jpeg"));

        //TUser.setPhotoBytes(Image.getBytes());
        return 0;
    }

    @GetMapping("/Users/Image/{username}")
    byte[] GetImage(@PathVariable String username){
        User TUser = repository.findByUsername(username);
        if( TUser == null ) return null;
        return TUser.getPhotoBytes();
    }

}
